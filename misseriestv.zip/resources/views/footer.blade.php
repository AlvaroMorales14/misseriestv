<footer>
  <div id="copyright text-center">

	<p>Sitio web desarrollado por: Alvaro Morales</p>
	<p>Laravel & PHP</p>
</div>
</footer>

<script type="text/javascript">
                $(document).ready(function () {
                    $('.sk-fading-circle').hide();//esta linea oculta el div cuando la pagina se acaba de cargar
                    $('form').submit(function () {
                        $('.sk-fading-circle').show();// esta linea muestra el div cuando se envia un formulario y se quita cuando la pagina se termino de cargar con el codigo de arriba
                    });
                });
        </script>
</body>
</html>

