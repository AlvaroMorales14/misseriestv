<!DOCTYPE html>
<html lang="en">
<?php echo $__env->make('head', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body>
	<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<h1><img src="imagenes\lacasalogo-crop-u77.png"> - Capítulos</h1>
<ul class="laListaDeCapitulos">
	<h2>Temporada 1</h2>
	<li><button class="btn btn-danger btn-sm" id="btn1" onclick="VerUnCapitulo(this)">Capitulo 1</button></li>
	<li><button class="btn btn-danger btn-sm" id="btn2" onclick="VerUnCapitulo(this)">Capitulo 2</button></li>
	<li><button class="btn btn-danger btn-sm" id="btn3" onclick="VerUnCapitulo(this)">Capitulo 3</button></li>
	<li><button class="btn btn-danger btn-sm" id="btn4" onclick="VerUnCapitulo(this)">Capitulo 4</button></li>
	<li><button class="btn btn-danger btn-sm" id="btn5" onclick="VerUnCapitulo(this)">Capitulo 5</button></li>
	<li><button class="btn btn-danger btn-sm" id="btn6" onclick="VerUnCapitulo(this)">Capitulo 6</button></li>
	<li><button class="btn btn-danger btn-sm" id="btn7" onclick="VerUnCapitulo(this)">Capitulo 7</button></li>
	<li><button class="btn btn-danger btn-sm" id="btn8" onclick="VerUnCapitulo(this)">Capitulo 8</button></li>
	<li><button class="btn btn-danger btn-sm" id="btn9" onclick="VerUnCapitulo(this)">Capitulo 9</button></li>
	<li><button class="btn btn-danger btn-sm" id="btn10" onclick="VerUnCapitulo(this)">Capitulo 10</button></li>
	<li><button class="btn btn-danger btn-sm" id="btn11" onclick="VerUnCapitulo(this)">Capitulo 11</button></li>
	<li><button class="btn btn-danger btn-sm" id="btn12" onclick="VerUnCapitulo(this)">Capitulo 12</button></li>
	<li><button class="btn btn-danger btn-sm" id="btn13" onclick="VerUnCapitulo(this)">Capitulo 13</button></li>
	<li><button class="btn btn-danger btn-sm" id="btn14" onclick="VerUnCapitulo(this)">Capitulo 14</button></li>
	<li><button class="btn btn-danger btn-sm" id="btn15" onclick="VerUnCapitulo(this)">Capitulo 15</button></li>

<!-- <h2>Temporada 2</h2>
	<li><button class="btn btn-danger btn-sm">Capitulo 1</button></li>
	<li><button class="btn btn-danger btn-sm">Capitulo 2</button></li>
	<li><button class="btn btn-danger btn-sm">Capitulo 3</button></li>
	<li><button class="btn btn-danger btn-sm">Capitulo 4</button></li>
	<li><button class="btn btn-danger btn-sm">Capitulo 5</button></li>
	<li><button class="btn btn-danger btn-sm">Capitulo 6</button></li>
	<li><button class="btn btn-danger btn-sm">Capitulo 7</button></li>
	<li><button class="btn btn-danger btn-sm">Capitulo 8</button></li>
	<li><button class="btn btn-danger btn-sm">Capitulo 9</button></li>
	<li><button class="btn btn-danger btn-sm">Capitulo 10</button></li>
	<li><button class="btn btn-danger btn-sm">Capitulo 11</button></li>
	<li><button class="btn btn-danger btn-sm">Capitulo 12</button></li>
	<li><button class="btn btn-danger btn-sm">Capitulo 13</button></li>
	<li><button class="btn btn-danger btn-sm">Capitulo 14</button></li>
	<li><button class="btn btn-danger btn-sm">Capitulo 15</button></li> -->
</ul>
<div class="laCajaDeVideo" id="elIFrame">

	<!-- Aca van los capitulos -->
	<iframe width="820" height="461" frameborder="0" src="https://mega.nz/embed#!Fz421CoT!PqVa3mYGc6BfY3ENp3q4xGrzVG7BGQk6N8ORuxcXCXY" allowfullscreen></iframe>

</div>

<script type="text/javascript">
	
function VerUnCapitulo(comp){
  			let id = comp.id;

  if (id=='btn1') {

  			document.getElementById('elIFrame').innerHTML="";
			var selector = document.getElementById('elIFrame');
		    var iframe = document.createElement('iframe');
  			iframe.setAttribute('width','820');
		    iframe.setAttribute('height','461');
		    iframe.setAttribute('id','elCapitulo');
		    iframe.setAttribute('allowfullscreen','');	
		    iframe.setAttribute('frameborder','0');	
		    					
		    //propiedades iframe
		    iframe.setAttribute('src','https://mega.nz/embed#!Fz421CoT!PqVa3mYGc6BfY3ENp3q4xGrzVG7BGQk6N8ORuxcXCXY');		    
		    //insertar iframe
		    selector.appendChild(iframe);
		    
  } else if (id=='btn2'){
									
		   	document.getElementById('elIFrame').innerHTML="";
			var selector = document.getElementById('elIFrame');
		    var iframe = document.createElement('iframe');
  			iframe.setAttribute('width','820');
		    iframe.setAttribute('height','461');
		    iframe.setAttribute('id','elCapitulo');
		    iframe.setAttribute('allowfullscreen','');	
		    iframe.setAttribute('frameborder','0');	

		    //propiedades iframe
		    iframe.setAttribute('src','https://mega.nz/embed#!giQGiSTa!E993XilxazfSi6OUfqrPMxC2fyT3v0JXFAv8SBhOKs8');		    
		    //insertar iframe
		    selector.appendChild(iframe);

  } else if (id=='btn3'){
									
		   	document.getElementById('elIFrame').innerHTML="";
			var selector = document.getElementById('elIFrame');
		    var iframe = document.createElement('iframe');
  			iframe.setAttribute('width','820');
		    iframe.setAttribute('height','461');
		    iframe.setAttribute('id','elCapitulo');
		    iframe.setAttribute('allowfullscreen','');	
		    iframe.setAttribute('frameborder','0');	

		    //propiedades iframe
		    iframe.setAttribute('src','https://mega.nz/embed#!V2gDQCBZ!9yuq7oj-5h57Z_Iawu5zEYvhIojGVo9p7pvc6-cbvwM');		    
		    //insertar iframe
		    selector.appendChild(iframe);

  } else if (id=='btn4'){
									
		   	document.getElementById('elIFrame').innerHTML="";
			var selector = document.getElementById('elIFrame');
		    var iframe = document.createElement('iframe');
  			iframe.setAttribute('width','820');
		    iframe.setAttribute('height','461');
		    iframe.setAttribute('id','elCapitulo');
		    iframe.setAttribute('allowfullscreen','');	
		    iframe.setAttribute('frameborder','0');	

		    //propiedades iframe
		    iframe.setAttribute('src','https://mega.nz/embed#!wjYBhJBQ!tMCFwFL2bWs9mWYDoG3E2I7gk0L1ExR6A58DadbfdS4');		    
		    //insertar iframe
		    selector.appendChild(iframe);

  } else if (id=='btn5'){
									
		   	document.getElementById('elIFrame').innerHTML="";
			var selector = document.getElementById('elIFrame');
		    var iframe = document.createElement('iframe');
  			iframe.setAttribute('width','820');
		    iframe.setAttribute('height','461');
		    iframe.setAttribute('id','elCapitulo');
		    iframe.setAttribute('allowfullscreen','');	
		    iframe.setAttribute('frameborder','0');	

		    //propiedades iframe
		    iframe.setAttribute('src','https://mega.nz/embed#!UzZVmaxL!8vd39GVK0mR_qLtenhRdW1VdQGt-pqerPkTgSxB1YMo');		    
		    //insertar iframe
		    selector.appendChild(iframe);

  } else if (id=='btn6'){
									
		   	document.getElementById('elIFrame').innerHTML="";
			var selector = document.getElementById('elIFrame');
		    var iframe = document.createElement('iframe');
  			iframe.setAttribute('width','820');
		    iframe.setAttribute('height','461');
		    iframe.setAttribute('id','elCapitulo');
		    iframe.setAttribute('allowfullscreen','');	
		    iframe.setAttribute('frameborder','0');	

		    //propiedades iframe
		    iframe.setAttribute('src','https://mega.nz/embed#!svgHQLjT!6DnVBXY-wR5BYPKFjFaiaXcJTvKWMFu2TGvjoeZ7XTU');		    
		    //insertar iframe
		    selector.appendChild(iframe);

  } else if (id=='btn7'){
									
		   	document.getElementById('elIFrame').innerHTML="";
			var selector = document.getElementById('elIFrame');
		    var iframe = document.createElement('iframe');
  			iframe.setAttribute('width','820');
		    iframe.setAttribute('height','461');
		    iframe.setAttribute('id','elCapitulo');
		    iframe.setAttribute('allowfullscreen','');	
		    iframe.setAttribute('frameborder','0');	

		    //propiedades iframe
		    iframe.setAttribute('src','https://mega.nz/embed#!JzAnAYTB!OtF7omelgVnw1bUECLIOJVrpV2XVURY3JRFVraFvU3I');		    
		    //insertar iframe
		    selector.appendChild(iframe);

  } else if (id=='btn8'){
									
		   	document.getElementById('elIFrame').innerHTML="";
			var selector = document.getElementById('elIFrame');
		    var iframe = document.createElement('iframe');
  			iframe.setAttribute('width','820');
		    iframe.setAttribute('height','461');
		    iframe.setAttribute('id','elCapitulo');
		    iframe.setAttribute('allowfullscreen','');	
		    iframe.setAttribute('frameborder','0');	

		    //propiedades iframe
		    iframe.setAttribute('src','https://mega.nz/embed#!56w3FTBD!h7XdiWx8abd-uOj3_R0e84928vhAKX8S3IW_HaAUQpg');		    
		    //insertar iframe
		    selector.appendChild(iframe);

  } else if (id=='btn9'){
									
		   	document.getElementById('elIFrame').innerHTML="";
			var selector = document.getElementById('elIFrame');
		    var iframe = document.createElement('iframe');
  			iframe.setAttribute('width','820');
		    iframe.setAttribute('height','461');
		    iframe.setAttribute('id','elCapitulo');
		    iframe.setAttribute('allowfullscreen','');	
		    iframe.setAttribute('frameborder','0');	

		    //propiedades iframe
		    iframe.setAttribute('src','https://mega.nz/embed#!Rihz3RpA!Tx_r0Ja29zpE9Ut3lerTx4AAwkZhdJahxLxZrDSiwqU');		    
		    //insertar iframe
		    selector.appendChild(iframe);

  } else if (id=='btn10'){
									
		   	document.getElementById('elIFrame').innerHTML="";
			var selector = document.getElementById('elIFrame');
		    var iframe = document.createElement('iframe');
  			iframe.setAttribute('width','820');
		    iframe.setAttribute('height','461');
		    iframe.setAttribute('id','elCapitulo');
		    iframe.setAttribute('allowfullscreen','');	
		    iframe.setAttribute('frameborder','0');	

		    //propiedades iframe
		    iframe.setAttribute('src','https://mega.nz/embed#!tzYUHZ4D!01q27tSKbfo4vqHEwI3oNCBMQ8xxkKF2aW4LxFRzsDs');		    
		    //insertar iframe
		    selector.appendChild(iframe);

  } else if (id=='btn11'){
									
		   	document.getElementById('elIFrame').innerHTML="";
			var selector = document.getElementById('elIFrame');
		    var iframe = document.createElement('iframe');
  			iframe.setAttribute('width','820');
		    iframe.setAttribute('height','461');
		    iframe.setAttribute('id','elCapitulo');
		    iframe.setAttribute('allowfullscreen','');	
		    iframe.setAttribute('frameborder','0');	

		    //propiedades iframe
		    iframe.setAttribute('src','https://mega.nz/embed#!RrQGgYYZ!mq00W7iO7KtBdL0kI4L8dd6Cl_dpHTo91SUpPFBugSQ');		    
		    //insertar iframe
		    selector.appendChild(iframe);

  } else if (id=='btn12'){
									
		   	document.getElementById('elIFrame').innerHTML="";
			var selector = document.getElementById('elIFrame');
		    var iframe = document.createElement('iframe');
  			iframe.setAttribute('width','820');
		    iframe.setAttribute('height','461');
		    iframe.setAttribute('id','elCapitulo');
		    iframe.setAttribute('allowfullscreen','');	
		    iframe.setAttribute('frameborder','0');	

		    //propiedades iframe
		    iframe.setAttribute('src','https://mega.nz/embed#!9uB3hQqB!azVO2GwC-TU6iI9HvXSXLWm86tcGB5b2Sdmiq9U6PTk');		    
		    //insertar iframe
		    selector.appendChild(iframe);

  } else if (id=='btn13'){
									
		   	document.getElementById('elIFrame').innerHTML="";
			var selector = document.getElementById('elIFrame');
		    var iframe = document.createElement('iframe');
  			iframe.setAttribute('width','820');
		    iframe.setAttribute('height','461');
		    iframe.setAttribute('id','elCapitulo');
		    iframe.setAttribute('allowfullscreen','');	
		    iframe.setAttribute('frameborder','0');	

		    //propiedades iframe
		    iframe.setAttribute('src','https://mega.nz/embed#!96BQVZoZ!sncUloHd-ogGd0O_bjfKqSL4rXp52SGLrkZ96gwMYTA');		    
		    //insertar iframe
		    selector.appendChild(iframe);

  } else if (id=='btn14'){
									
		   	document.getElementById('elIFrame').innerHTML="";
			var selector = document.getElementById('elIFrame');
		    var iframe = document.createElement('iframe');
  			iframe.setAttribute('width','820');
		    iframe.setAttribute('height','461');
		    iframe.setAttribute('id','elCapitulo');
		    iframe.setAttribute('allowfullscreen','');	
		    iframe.setAttribute('frameborder','0');	

		    //propiedades iframe
		    iframe.setAttribute('src','https://mega.nz/embed#!4iomDbwJ!CuVgIpg_3QgUbUs8yBmxIvNhaTl1KxsqyLds8OK9UGc');		    
		    //insertar iframe
		    selector.appendChild(iframe);

  } else if (id=='btn15'){
									
		   	document.getElementById('elIFrame').innerHTML="";
			var selector = document.getElementById('elIFrame');
		    var iframe = document.createElement('iframe');
  			iframe.setAttribute('width','820');
		    iframe.setAttribute('height','461');
		    iframe.setAttribute('id','elCapitulo');
		    iframe.setAttribute('allowfullscreen','');	
		    iframe.setAttribute('frameborder','0');	

		    //propiedades iframe
		    iframe.setAttribute('src','https://mega.nz/embed#!EvYyFRRB!ffNDqlX7NOitch8gmq28yQHDZXL0BtnMJZ5fRFztiuY');		    
		    //insertar iframe
		    selector.appendChild(iframe);

  }

}

</script>

</body>
</html>